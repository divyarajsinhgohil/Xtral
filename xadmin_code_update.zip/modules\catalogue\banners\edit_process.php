<?php
require_once dirname(__DIR__, 3) . '/config/db.php';
requireLogin();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: list.php");
    exit;
}

try {
    $pdo = getDBConnection();

    $id = $_POST['id'] ?? null;
    if (!$id) throw new Exception("Invalid banner ID.");

    $banner = fetchOne("SELECT * FROM catalogue_banners WHERE id = ?", [$id]);
    if (!$banner) throw new Exception("Banner not found.");

    $title = sanitize($_POST['title'] ?? '');
    $link_url = sanitize($_POST['link_url'] ?? '');
    $display_order = (int)($_POST['display_order'] ?? 0);
    $is_active = isset($_POST['is_active']) ? 1 : 0;

    if (empty($title)) {
        throw new Exception("Banner title is required.");
    }

    $image_url = $banner['image_url']; // Keep existing

    // Handle New Image Upload
    if (isset($_FILES['image']) && $_FILES['image']['error'] === UPLOAD_ERR_OK) {
        $uploadResult = handleFileUpload($_FILES['image'], 'catalogue/banners', ['image/jpeg', 'image/png', 'image/webp']);
        if ($uploadResult['success']) {
            // Delete old image
            if ($banner['image_url']) {
                deleteUploadedFile('catalogue/banners/' . $banner['image_url']);
            }
            $image_url = $uploadResult['filename'];
        }
    }

    // Update
    $sql = "UPDATE catalogue_banners SET title=?, image_url=?, link_url=?, display_order=?, is_active=? WHERE id=?";
    $stmt = $pdo->prepare($sql);
    $stmt->execute([$title, $image_url, $link_url ?: null, $display_order, $is_active, $id]);

    $_SESSION['success'] = "Banner '$title' updated successfully!";
} catch (Exception $e) {
    $_SESSION['error'] = "Error: " . $e->getMessage();
}

header("Location: list.php");
exit;
